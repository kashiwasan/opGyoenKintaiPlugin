<h2>勤怠記録設定</h2>

<form action="<?php url_for('opGyoenKintaiPlugin/index') ?>" method="POST">
  <table>
  <?php echo $form; ?>
    <tr>
      <td colspan="2"><input type="submit" value="変更" /></td>
    </tr>
  </table>
</form>

