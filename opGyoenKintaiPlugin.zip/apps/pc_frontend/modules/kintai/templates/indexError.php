<div id="Center">
<div class="partsHeading"><h3>エラー</h3></div>
<div class="block">
エラーが発生しました。
・<?=$error ?>
</div>
