v id="Center">
<div class="partsHeading"><h3>勤怠報告をする</h3></div>
<div class="block">
<span style="color: #FF0000">エラーの項目があります！</span><br />
<br />

</div>
