<div id="Center">
<div class="partsHeading"><h3>勤怠報告完了</h3></div>
<div class="block">
勤怠報告が完了いたしました。<br />
お疲れさまです。<br />
<br />

</div>
