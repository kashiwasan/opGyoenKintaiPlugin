
<div class="partsHeading"><h3>勤怠報告エラー</h3></div>
<div class="block">
<span style="color: #FF0000;">問題が発生したため、勤怠報告が正常にされなかった可能性があります。<br />
再度報告するか、事務にまでお問い合わせください。<br />
<?=$message; ?>
</div>
