<div class="parts">

<div class="partsHeading"><h3><a href="/kintai"><?=$memberName ?>さんの勤怠</a></h3></div>
<a href="/kintai/in" class="green-button pcb" rel="prettyPopin">
<span>今から出勤しまーす</span>
</a>
<br />

<a href="/kintai/out" class="red-button pcb" rel="prettyPopin">
<span>今から帰りまーす</span>
</a>

</div>

