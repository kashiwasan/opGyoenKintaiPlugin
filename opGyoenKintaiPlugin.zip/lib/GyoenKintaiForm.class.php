<?php
class GyoenKintaiForm extends sfForm
{
  public function configure(){

  }

}

?>

